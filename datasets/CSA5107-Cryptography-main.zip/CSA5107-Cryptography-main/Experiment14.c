#include <stdio.h>
#include <string.h>

int main() {

    char text[100];
    int key[100];
    int n,i;

    printf("Enter Plaintext (uppercase, no spaces): ");
    scanf("%s", text);

    n=strlen(text);

    printf("Enter %d key values:\n",n);

    for(i=0;i<n;i++)
        scanf("%d",&key[i]);

    printf("Ciphertext: ");

    for(i=0;i<n;i++)
    {
        int c=((text[i]-'A')+key[i])%26;
        printf("%c",c+'A');
    }

    return 0;
}